﻿namespace AndonLights.Model;

public class Notification
{
    public int Id { get; set; }
    public string newState { get; set; }
    public string ErrorMessage { get; set; }

}
