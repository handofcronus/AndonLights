﻿namespace AndonLights.Services.Interfaces;

public interface IApiKeyService
{
    string GenerateApiKey();
}
