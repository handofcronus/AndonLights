﻿namespace AndonLights.DTOs;

public class UpdateLightDTO
{ 
    public int Id { get; set; }
    public string Name { get; set; }
}
