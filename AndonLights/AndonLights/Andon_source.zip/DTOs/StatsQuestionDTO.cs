﻿
namespace AndonLights.DTOs;

public  class StatsQuestionDTO
{
    public int Id { get; set; }
    public DateTime Date { get; set; }
}

