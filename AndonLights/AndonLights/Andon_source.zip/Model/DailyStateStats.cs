﻿namespace AndonLights.Model;

public class DailyStateStats : StatsBase
{
    public DailyStateStats() : base() { }
}
