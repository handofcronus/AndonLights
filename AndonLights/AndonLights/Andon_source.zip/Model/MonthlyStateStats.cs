﻿namespace AndonLights.Model;

public class MonthlyStateStats : StatsBase
{
    public MonthlyStateStats() :base() { }
}
